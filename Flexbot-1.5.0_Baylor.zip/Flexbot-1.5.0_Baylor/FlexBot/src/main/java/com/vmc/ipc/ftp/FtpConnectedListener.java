package com.vmc.ipc.ftp;

public interface FtpConnectedListener {
    public void onFtpConnect();
    public void onFtpDisconnect();
}
