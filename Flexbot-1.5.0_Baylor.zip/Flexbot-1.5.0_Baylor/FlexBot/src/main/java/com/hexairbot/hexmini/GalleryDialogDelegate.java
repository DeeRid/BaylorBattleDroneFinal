package com.hexairbot.hexmini;

public interface GalleryDialogDelegate {
    public void prepareDialog(GalleryDialog dialog);
    public void onDismissed(GalleryDialog settingsDialog);
}

