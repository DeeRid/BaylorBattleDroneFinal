package com.hexairbot.hexmini.modal;

public interface OSDDataDelegate {
	public void  osdDataDidUpdateOneFrame();
}

