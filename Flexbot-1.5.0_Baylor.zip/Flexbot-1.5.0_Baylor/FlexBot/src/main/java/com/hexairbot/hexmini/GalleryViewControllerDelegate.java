package com.hexairbot.hexmini;

public interface GalleryViewControllerDelegate {

}
