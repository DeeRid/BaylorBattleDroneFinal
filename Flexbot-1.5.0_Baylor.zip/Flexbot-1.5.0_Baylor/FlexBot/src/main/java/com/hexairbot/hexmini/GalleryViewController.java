package com.hexairbot.hexmini;


import android.view.View;
import android.view.View.OnClickListener;

public class GalleryViewController  extends ViewController
implements OnClickListener{

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		
	}

}
