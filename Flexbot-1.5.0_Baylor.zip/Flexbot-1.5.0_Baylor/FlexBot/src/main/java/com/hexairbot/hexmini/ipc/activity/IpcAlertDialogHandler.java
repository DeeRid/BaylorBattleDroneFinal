package com.hexairbot.hexmini.ipc.activity;

public interface IpcAlertDialogHandler {
    public void positive();

    public void negtive();
}
