/**
 * 
 */
package com.hexairbot.hexmini;

import com.hexairbot.hexmini.ui.Button;

import android.view.View;


/**
 * @author koupoo
 *
 */
public interface HudViewControllerDelegate {
	public void settingsBtnDidClick(View settingsBtn);
}
