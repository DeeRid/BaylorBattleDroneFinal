package com.hexairbot.hexmini;

public class Const {
	
	public static String web_site = "http://118.244.224.19";
	public static String user_feedback_url = web_site + "/flexbot-feedback.php";
	
}
