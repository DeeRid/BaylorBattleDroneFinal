#ifndef VMC__JPEGENC_H

#define VMC__JPEGENC_H



int get_photo(char * dest_dir,char * name, bool location_flag);


#endif //VMC__JPEGENC_H

